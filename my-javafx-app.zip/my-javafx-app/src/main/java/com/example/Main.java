package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;
import javafx.beans.property.SimpleStringProperty;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Legislators Table");

        // Sample data
        Legislator[] legislators = {
            new Legislator("1", "Alice"),
            new Legislator("2", "Bob"),
            new Legislator("3", "Charlie"),
            // Add more legislators as needed
        };

        TableView<Legislator> table = new TableView<>();
        
        // Create column for reset button
        TableColumn<Legislator, Void> resetColumn = new TableColumn<>("Reset");
        resetColumn.setCellFactory(col -> new TableCell<Legislator, Void>() {
            private final Button resetButton = new Button("Reset");

            {
                resetButton.setOnAction(event -> {
                    Legislator currentLegislator = getTableView().getItems().get(getIndex());
                    currentLegislator.resetStatus();
                    getTableView().refresh(); // Refresh the table to update the view
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(resetButton);
                }
            }
        });

        // Create column for legislator names
        TableColumn<Legislator, String> nameColumn = new TableColumn<>("Legislator");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        // Create columns for each status
        TableColumn<Legislator, String> ayesColumn = createStatusColumn("Ayes", legislators);
        TableColumn<Legislator, String> noesColumn = createStatusColumn("Noes", legislators);
        TableColumn<Legislator, String> absentColumn = createStatusColumn("Absent", legislators);
        TableColumn<Legislator, String> nvColumn = createStatusColumn("NV", legislators);
        TableColumn<Legislator, String> vacancyColumn = createStatusColumn("Vacancy", legislators);

        table.getColumns().addAll(resetColumn, nameColumn, ayesColumn, noesColumn, absentColumn, nvColumn, vacancyColumn);
        table.getItems().addAll(legislators);

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table);
        Scene scene = new Scene(vbox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private TableColumn<Legislator, String> createStatusColumn(String statusName, Legislator[] legislators) {
        TableColumn<Legislator, String> column = new TableColumn<>(statusName);
        column.setCellValueFactory(cellData -> cellData.getValue().getStatusProperty(statusName));
        column.setCellFactory(col -> new TableCell<Legislator, String>() {
            private final RadioButton radioButton = new RadioButton();

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                } else {
                    // Update the radio button state
                    radioButton.setSelected(item.equals("Yes"));

                    // Handle radio button action
                    radioButton.setOnAction(event -> {
                        for (Legislator legislator : legislators) {
                            legislator.resetStatus();
                        }
                        getTableView().getItems().get(getIndex()).setStatus(statusName, "Yes");
                        getTableView().refresh(); // Refresh the table to update the view
                    });

                    setGraphic(radioButton); // Set the radio button as the graphic for the cell
                }
            }
        });
        return column;
    }
}

class Legislator {
    private final SimpleStringProperty id;
    private final SimpleStringProperty name;
    private final Map<String, String> statusMap;

    public Legislator(String id, String name) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.statusMap = new HashMap<>();
        resetStatus();
    }

    public String getId() {
        return id.get();
    }

    public SimpleStringProperty idProperty() {
        return id;
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setStatus(String status, String value) {
        statusMap.put(status, value);
    }

    public void resetStatus() {
        for (String status : new String[]{"Ayes", "Noes", "Absent", "NV", "Vacancy"}) {
            statusMap.put(status, "No");
        }
    }

    public String getStatus(String status) {
        return statusMap.get(status);
    }

    public SimpleStringProperty getStatusProperty(String status) {
        return new SimpleStringProperty(getStatus(status));
    }
}
